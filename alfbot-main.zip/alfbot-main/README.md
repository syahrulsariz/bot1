<div align="center">
    <img alt="alfbot" src ="https://i.ibb.co/jD65tdm/62-812-1347-7896-20201109-230938.jpg" width="320">
    <h3> BOT WHATSAPP YANG BISA DIGUNAKAN DI TERMUX </h3>
# ALF BOT
</div>


## CARA INSTALL

### TERMUX
```bash
> download termux
> buka
> pkg install git
> git clone https://github.com/alfiansx/alfbot
> cd alfbot
> bash install.sh
> node index.js
```


## FITUR

| KEADAAN       |               FITUR     |
| :-----------: | :--------------------------------:  |
|       ✅       |    PANTUN                         |
|       ✅       | ANIMEPICT                         |
|       ✅       | STICKER                           |
|       ✅       | NULIS 
|       ✅       | OCR                               |
|       ✅       | QUOTES                            |
|       ✅       | RANDOM PICT                       |
|       ✅       | ANIMEPICT                         |
|       ✅       | LIRIK                             |
|       ✅       | ALAY                              |
|       ✅       | YT,YTMP3,TWT,TIK TOK DOWNLOADER   |
|       ✅       | WIKIPEDIA                         |
|       ✅       | ARTI NAMA                         |
|       ✅       | SHOLAT                            |
|       ✅       | QURAN                             |

✅ aktif


## THANKS TO
* [`termux-whatsapp-bot`](https://github.com/fdciabdul/termux-whatsapp-bot)
* [`botst4rz`](https://github.com/Bintang73/botst4rz)
* [`ibnusyawall`](https://github.com/ibnusyawall)

## DONASI
* [`Saweria`](https://saweria.com/aditiaalfians)
